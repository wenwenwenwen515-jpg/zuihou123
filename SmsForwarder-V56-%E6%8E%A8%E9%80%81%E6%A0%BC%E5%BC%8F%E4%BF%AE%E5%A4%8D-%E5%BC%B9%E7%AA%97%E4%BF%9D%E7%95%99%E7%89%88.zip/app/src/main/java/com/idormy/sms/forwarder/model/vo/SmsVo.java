package com.idormy.sms.forwarder.model.vo;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.utils.SettingUtil;
import com.idormy.sms.forwarder.utils.PhoneUtils;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;

@Data
public class SmsVo implements Serializable {
    String mobile;
    String content;
    Date date;
    String simInfo;

    public SmsVo() {
    }

    public SmsVo(String mobile, String content, Date date, String simInfo) {
        this.mobile = mobile;
        this.content = content;
        this.date = date;
        this.simInfo = simInfo;
    }

    @SuppressLint("SimpleDateFormat")
    public String getSmsVoForSend(String ruleSmsTemplate) {
        String deviceMark = SettingUtil.getAddExtraDeviceMark().trim();

        // 优先保留转发规则或用户在设置中自定义的模板；未自定义时使用简洁推送格式。
        if (ruleSmsTemplate != null && !ruleSmsTemplate.isEmpty()) {
            return applyTemplate(ruleSmsTemplate, deviceMark);
        }
        boolean switchSmsTemplate = SettingUtil.getSwitchSmsTemplate();
        String smsTemplate = SettingUtil.getSmsTemplate().trim();
        if (switchSmsTemplate && !smsTemplate.isEmpty()) {
            return applyTemplate(smsTemplate, deviceMark);
        }

        StringBuilder out = new StringBuilder();
        // 发送方号码属于收到短信的来源号码，不是本机 SIM 卡号码。
        if (!TextUtils.isEmpty(mobile) && !mobile.trim().isEmpty()) {
            out.append(mobile.trim()).append(" ");
        }
        if (content != null && !content.trim().isEmpty()) out.append(content.trim());
        out.append("\n");

        String rawNumber = getSimNumber(simInfo);
        String slotLine = buildSimLine(simInfo, rawNumber);
        if (!TextUtils.isEmpty(slotLine)) out.append(slotLine).append("\n");

        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        String maker = friendlyBrand(manufacturer, brand);
        String modelSuffix = getSimDigit(rawNumber, 5);
        String device = (maker + " " + model).trim();
        if (!TextUtils.isEmpty(modelSuffix)) device += modelSuffix;
        if (!device.isEmpty()) out.append("设备：").append(device).append("\n");

        String system = getFriendlySystemVersion();
        if (!TextUtils.isEmpty(system)) out.append("系统：").append(system).append("\n");

        int battery = PhoneUtils.getBatteryPercent();
        if (battery >= 0) out.append("电量：").append(battery).append("\n");
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String suffix = getSimDigit(rawNumber, 8);
        out.append("推送时间：").append(time).append(suffix).append("\n");

        // 去掉末尾多余换行。
        return out.toString().trim();
    }

    private String applyTemplate(String template, String deviceMark) {
        return template.replace("{{来源号码}}", mobile == null ? "" : mobile)
                .replace("{{APP包名}}", mobile == null ? "" : mobile)
                .replace("{{短信内容}}", content == null ? "" : content)
                .replace("{{通知内容}}", content == null ? "" : content)
                .replace("{{卡槽信息}}", simInfo == null ? "" : simInfo)
                .replace("{{接收时间}}", date == null ? "" : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date))
                .replace("{{设备名称}}", deviceMark).trim();
    }

    private String getSimNumber(String info) {
        int slot = 1;
        try {
            if (info != null && info.startsWith("SIM") && info.length() >= 4) {
                char c = info.charAt(3);
                if (Character.isDigit(c)) slot = Character.digit(c, 10);
            }
        } catch (Exception ignored) { }
        String number = PhoneUtils.getSimPhoneNumber(slot);
        if (TextUtils.isEmpty(number) && info != null) {
            int underscore = info.indexOf('_');
            if (underscore >= 0 && underscore + 1 < info.length()) {
                String possible = info.substring(underscore + 1).trim();
                if (possible.matches("[+0-9() -]{5,}")) number = possible;
            }
        }
        return number == null ? "" : number.trim();
    }

    private String buildSimLine(String info, String rawNumber) {
        int slot = 1;
        try {
            if (info != null && info.startsWith("SIM") && info.length() >= 4) {
                char c = info.charAt(3);
                if (Character.isDigit(c)) slot = Character.digit(c, 10);
            }
        } catch (Exception ignored) { }
        if (TextUtils.isEmpty(rawNumber)) return "卡" + slot;
        String digits = rawNumber.replaceAll("\\D", "");
        String masked = rawNumber;
        if (digits.length() >= 7) {
            // Keep the first four and last three digits, masking the middle four (or middle span).
            masked = digits.substring(0, 4) + "****" + digits.substring(digits.length() - 3);
        }
        return "卡" + slot + "：" + masked;
    }

    /** Returns a one-based digit from the local SIM number, or empty if unavailable. */
    private String getSimDigit(String rawNumber, int position) {
        if (TextUtils.isEmpty(rawNumber) || position < 1) return "";
        String digits = rawNumber.replaceAll("\\D", "");
        return digits.length() >= position ? digits.substring(position - 1, position) : "";
    }

    private String friendlyBrand(String manufacturer, String brand) {
        String all = (manufacturer + " " + brand).toLowerCase();
        if (all.contains("huawei")) return "华为";
        if (all.contains("honor")) return "荣耀";
        if (all.contains("xiaomi") || all.contains("redmi") || all.contains("poco")) return "小米";
        if (all.contains("oppo") || all.contains("oplus")) return "OPPO";
        if (all.contains("vivo") || all.contains("iqoo")) return "vivo";
        if (all.contains("samsung")) return "三星";
        if (all.contains("oneplus")) return "一加";
        if (all.contains("motorola") || all.contains("moto")) return "摩托罗拉";
        return !TextUtils.isEmpty(manufacturer) ? manufacturer : brand;
    }

    private String getFriendlySystemVersion() {
        String display = Build.DISPLAY == null ? "" : Build.DISPLAY.trim();
        // 优先识别厂商系统版本，避免把 Flyme 等厂商字符串拼到 Android 版本后面。
        java.util.regex.Matcher harmony = java.util.regex.Pattern.compile("(?i)HarmonyOS\\s*([0-9]+(?:\\.[0-9]+){1,3})").matcher(display);
        if (harmony.find()) return "HarmonyOS " + harmony.group(1);
        java.util.regex.Matcher emui = java.util.regex.Pattern.compile("(?i)EMUI\\s*([0-9]+(?:\\.[0-9]+){0,2})").matcher(display);
        if (emui.find()) return "EMUI " + emui.group(1);
        java.util.regex.Matcher flyme = java.util.regex.Pattern.compile("(?i)Flyme\\s*([0-9]+(?:\\.[0-9]+){0,2})").matcher(display);
        if (flyme.find()) return "Flyme " + flyme.group(1);
        String release = Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE.trim();
        return release.isEmpty() ? "" : "Android " + release;
    }

    @NonNull
    @Override
    public String toString() {
        return "SmsVo{" +
                "mobile='" + mobile + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", simInfo=" + simInfo +
                '}';
    }
}
